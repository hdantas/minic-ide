package MiniC;

public class MiniCParseController extends MiniCParseControllerGenerated 
{ }