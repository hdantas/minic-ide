package MiniChdantas;

public class MiniCParseController extends MiniCParseControllerGenerated 
{ }