package MiniJava;

public class MiniJavaParseController extends MiniJavaParseControllerGenerated 
{ }