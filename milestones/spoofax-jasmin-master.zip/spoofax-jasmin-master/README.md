spoofax-JasminXT
================

Eclipse editor for JasminXT, an assembler for the Java Virtual Machine