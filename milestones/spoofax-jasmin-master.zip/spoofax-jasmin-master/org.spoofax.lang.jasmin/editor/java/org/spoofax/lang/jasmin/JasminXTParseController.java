package org.spoofax.lang.jasmin;

public class JasminXTParseController extends JasminXTParseControllerGenerated 
{ }